package com.ruoyi.common.constant;

/**
 * Shiro通用常量
 * 
 * @author ruoyi
 */
public class ShiroConstants
{
    /**
     * 当前登录的用户
     */
    public static final String CURRENT_USER = "currentUser";

    /**
     * 用户名字段
     */
    public static final String CURRENT_USERNAME = "username";

    /**
     * 锁定屏幕字段
     */
    public static final String LOCK_SCREEN = "lockscreen";

    /**
     * 消息key
     */
    public static final String MESSAGE = "message";

    /**
     * 错误key
     */
    public static final String ERROR = "errorMsg";

    /**
     * csrf session content
     */
    public static final String CSRF_TOKEN = "csrf_token";

    /**
     * csrf request header
     */
    public static final String X_CSRF_TOKEN = "X-CSRF-Token";

    /**
     * 当前在线会话
     */
    public static final String ONLINE_SESSION = "online_session";

    /**
     * 验证码key
     */
    public static final String CURRENT_CAPTCHA = "captcha";

    /**
     * 验证码开关
     */
    public static final String CURRENT_ENABLED = "captchaEnabled";

    /**
     * 验证码类型
     */
    public static final String CURRENT_TYPE = "captchaType";

    /**
     * 验证码
     */
    public static final String CURRENT_VALIDATECODE = "validateCode";

    /**
     * 验证码错误
     */
    public static final String CAPTCHA_ERROR = "captchaError";

    /**
     * 登录记录缓存
     */
    public static final String LOGIN_RECORD_CACHE = "loginRecordCache";

    /**
     * 系统活跃用户缓存
     */
    public static final String SYS_USERCACHE = "sys-userCache";
}
